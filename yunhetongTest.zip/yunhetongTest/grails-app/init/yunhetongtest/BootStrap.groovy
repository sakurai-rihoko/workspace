package yunhetongtest

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
