package com.yun.util;

/**
 * ngw配置信息
 * Created by tangjixiong on 2017/6/6.
 */
public class NgwConfig {
//    public static final String  _NGW_HOST="http://106.15.88.190:8000/";
    public static final String  _NGW_HOST="http://106.15.88.190:8000/";
}
